var TasksScopeEdit = (function ($) {

    TasksScopeEdit = function(options) {
        var that = this;
console.log(options);
        // DOM
        that.$wrapper = options["$wrapper"];
        that.$form = that.$wrapper.find('form');
        that.$sidebar = $('#t-settings-sidebar-wrapper');

        // VARS
        that.messages = options.messages || {};
        that.scope = options.scope || {};
        that.just_saved = options.just_saved || false;
        that.errors = options.errors || {};

        // DYNAMIC VARS

        // INIT
        that.init();
    };

    TasksScopeEdit.prototype.init = function () {
        var that = this;
        that.ensureCorrectHash();
        that.showSavedIndicator();
        that.showErrors();
        that.initDatepicker();
        that.initDeleteLink();
        that.initSubmit();
        that.initSidebar();
        that.initArchiveLink();
        that.initRestoreLink();
    };

    TasksScopeEdit.prototype.initSubmit = function () {
        var that = this,
            $form = that.$form;
        $form.submit(function () {
            that.submit();
            return false;
        });
    };

    TasksScopeEdit.prototype.submit = function (data) {
        var that = this;
        var $form = that.$form;
        var $submitButton = $form.find('button[type="submit"]');
        var due_date = $form.find('.datepicker-due-date').datepicker('getDate');
        var start_date = $form.find('.datepicker-start-date').datepicker('getDate');
        var end_date = $form.find('.datepicker-end-date').datepicker('getDate');

        $submitButton.attr('disabled', true);
        $submitButton.find('.fa-spinner').fadeIn();

        if (!due_date) {
            $form.find('[name="milestone[due_date]"]').val('');
        }
        if (!start_date) {
            $form.find('[name="milestone[start_date]"]').val('');
        }
        if (!end_date) {
            $form.find('[name="milestone[end_date]"]').val('');
        }

        const $disabled = $form.find(':disabled').prop('disabled', false);
        var form_data = $form.serializeArray();
        $disabled.prop('disabled', true); 

        if ($.isArray(data) && data.length) {
            form_data = form_data.concat(data);
        }

        $.post($form.attr('action'), form_data, function (r) {
            setTimeout(() => {
                $('#content').html(r);
            }, 1000);
        });
    };

    TasksScopeEdit.prototype.initDeleteLink = function () {
        var that = this,
            $wrapper = that.$wrapper,
            $form = that.$form,
            $link = $wrapper.find('.t-scope-delete-link'),
            confirm_msg = that.messages.delete_confirm || '';

        $link.on('click', function() {
            if (confirm(confirm_msg)) {
                $(this).find('.icon16').attr('class', 'icon16 loading');
                $.post('?module=milestones&action=delete', { id: $form.find('[name="id"]').val() }, function() {
                    $.wa.setHash('#/settings/');
                }, 'json');
            }
        });
    };

    TasksScopeEdit.prototype.initSidebar = function () {
        var that = this,
            $sidebar = that.$sidebar,
            scope = that.scope;
        if (scope.id > 0) {
            $sidebar.data('sidebar').selectItem('scope', scope.id);
        }
    };

    TasksScopeEdit.prototype.initDatepicker = function () {
        var ms;
        var date;
        var $date_hidden_field;
        var that = this;
        var $form = that.$form;

        $date_hidden_field = $form.find('[name="milestone[due_date]"]');
        ms = Date.parse($date_hidden_field.val());
        date = ms ? new Date(ms) : null;
        $form.find('.datepicker-due-date').datepicker({
            changeYear: true,
            changeMonth: true,
            gotoCurrent: true,
            constrainInput: false,
            altField: $date_hidden_field,
            altFormat: 'yy-mm-dd'
        }).datepicker("setDate", date);

        $date_hidden_field = $form.find('[name="milestone[start_date]"]');
        ms = Date.parse($date_hidden_field.val());
        date = ms ? new Date(ms) : null;
        $form.find('.datepicker-start-date').datepicker({
            changeYear: true,
            changeMonth: true,
            gotoCurrent: true,
            constrainInput: false,
            altField: $date_hidden_field,
            altFormat: 'yy-mm-dd'
        }).datepicker("setDate", date);

        $date_hidden_field = $form.find('[name="milestone[end_date]"]');
        ms = Date.parse($date_hidden_field.val());
        date = ms ? new Date(ms) : null;
        $form.find('.datepicker-end-date').datepicker({
            changeYear: true,
            changeMonth: true,
            gotoCurrent: true,
            constrainInput: false,
            altField: $date_hidden_field,
            altFormat: 'yy-mm-dd'
        }).datepicker("setDate", date);
    };

    TasksScopeEdit.prototype.ensureCorrectHash = function () {
        var that = this;
        if (that.scope.id > 0) {
            $.tasks.forceHash('#/settings/scope/' + that.scope.id + '/');
        }
    };

    TasksScopeEdit.prototype.showSavedIndicator = function () {
        var that = this;
        if (!that.just_saved) {
            return;
        }
        var $wrapped = that.$wrapper,
            $saved = $wrapped.find('.t-saved');
        $saved.slideDown();
        setTimeout(function () {
            $saved.slideUp();
        }, 3000);
    };

    TasksScopeEdit.prototype.showErrors = function () {
        var that = this,
            $form = that.$form,
            errors = that.errors;
        $.each(errors, function(field_name, error) {
            var $field = $form.find('[name="'+field_name+'"]:visible:first').addClass('state-error');
            if (!$field.length) {
                $field = $form.find('[name="'+field_name+'"]:first').siblings(':visible:input:first').addClass('state-error');
            }
            if (!$field.length) {
                $field = $form.find('[name="'+field_name+'"]:first').siblings('.dropdown').addClass('state-error');
            }
            if (!$field.length) {
                $field = $form.find(':submit:first');
            }
            $field.after($('<em class="state-error-hint"></em>').text(error));
        });

        // Clear validation errors when user changes the field
        that.$form.on('change keyup', '.state-error', function() {
            $(this).removeClass('state-error').siblings('.state-error-hint').remove();
        });
    };

    TasksScopeEdit.prototype.initArchiveLink = function () {
        var that = this,
            $wrapper = that.$wrapper;
        $wrapper.find('.t-scope-archive-link').click(function (e) {
            e.preventDefault();
            that.submit([{
                name: 'milestone[closed]',
                value: '1'
            }]);
        });
    };

    TasksScopeEdit.prototype.initRestoreLink = function () {
        var that = this,
            $wrapper = that.$wrapper;
        $wrapper.find('.t-scope-restore-link').click(function (e) {
            e.preventDefault();
            that.submit([{
                name: 'milestone[closed]',
                value: '0'
            }]);
        });
    };

    return TasksScopeEdit;

})(jQuery);
